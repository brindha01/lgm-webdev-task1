const ScrollHandler = (ElemID) => {
  let elem = document.querySelector(ElemID);
  elem.scrollIntoView();
};

var rd1 = document.getElementById("back-1");
var rd2 = document.getElementById("back-2");
var rd3 = document.getElementById("back-3");
var rd4 = document.getElementById("back-4");
var rd5 = document.getElementById("back-5");
const backing = document.querySelector("#header");
rd1.addEventListener("click", () => {
  backing.style.backgroundImage = "url('img/1.jpg')";
});
rd2.addEventListener("click", () => {
  backing.style.backgroundImage = "url('img/2.jpg')";
});

rd3.addEventListener("click", () => {
  backing.style.backgroundImage = "url('img/3.jpg')";
});

rd4.addEventListener("click", () => {
  backing.style.backgroundImage = "url('img/4.jpg')";
});
rd5.addEventListener("click", () => {
  backing.style.backgroundImage = "url('img/5.jpg')";
});
